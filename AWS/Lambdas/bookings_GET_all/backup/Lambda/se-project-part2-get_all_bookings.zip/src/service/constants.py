

SERVICE_NAME = "bookings_GET_all"
RESOURCE_NAME = "dynamodb"
BOOKINGS_DB_ENDPOINT = "http://localhost:8000"
TABLE_NAME = "bookings"