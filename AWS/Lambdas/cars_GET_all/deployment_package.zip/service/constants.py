

SERVICE_NAME = "cars_GET_all"
RESOURCE_NAME = "dynamodb"
TABLE_NAME = "cars"