

SERVICE_NAME = "bookings_GET_all"
RESOURCE_NAME = "dynamodb"
TABLE_NAME = "bookings"